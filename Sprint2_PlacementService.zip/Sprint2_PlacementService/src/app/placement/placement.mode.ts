export interface Placement {
    id?:number;
    companyName:string;
    jobTitile:string;
    placementDate:Date;
    studentId:number;
 

}
